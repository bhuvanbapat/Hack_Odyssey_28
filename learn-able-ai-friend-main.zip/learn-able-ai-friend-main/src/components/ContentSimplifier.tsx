
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Wand2, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

const ContentSimplifier = () => {
  const [originalText, setOriginalText] = useState("");
  const [simplifiedText, setSimplifiedText] = useState("");
  const [isSimplifying, setIsSimplifying] = useState(false);
  const [complexity, setComplexity] = useState("medium");

  const simplifyContent = async () => {
    if (!originalText) {
      toast.error("Please enter some text to simplify");
      return;
    }

    setIsSimplifying(true);
    
    // Simulate AI processing with a timeout
    // In a real app, this would be an API call to an AI service
    setTimeout(() => {
      try {
        // Simple text transformation logic (placeholder for AI processing)
        let result = originalText;
        
        // Replace complex words with simpler alternatives
        const complexWords: Record<string, string> = {
          "utilize": "use",
          "implement": "use",
          "facilitate": "help",
          "leverage": "use",
          "subsequently": "then",
          "furthermore": "also",
          "nevertheless": "but",
          "consequently": "so",
          "approximately": "about",
          "sufficient": "enough",
          "commence": "start",
          "terminate": "end",
          "endeavor": "try",
          "demonstrate": "show",
          "comprehend": "understand",
        };
        
        // Basic transformations based on complexity level
        Object.entries(complexWords).forEach(([complex, simple]) => {
          const regex = new RegExp(complex, "gi");
          result = result.replace(regex, simple);
        });
        
        // Simplify sentence structure based on complexity level
        if (complexity === "low") {
          // Break into shorter sentences
          result = result.replace(/([.!?])\s+([A-Z])/g, "$1\n\n$2");
          // Add explanations for potentially difficult concepts
          result = result.replace(/([a-z]+ion)(\s|\.)/g, "$1 (this means an action or process)$2");
        }
        
        setSimplifiedText(result);
        toast.success("Text successfully simplified");
      } catch (error) {
        toast.error("Error simplifying text");
        console.error(error);
      } finally {
        setIsSimplifying(false);
      }
    }, 1500);
  };

  return (
    <Card className="feature-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="mr-2 h-5 w-5 text-purple" />
          Content Simplifier
        </CardTitle>
        <CardDescription>
          Transform complex content into easier-to-understand language
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs defaultValue="original" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="original">Original Text</TabsTrigger>
            <TabsTrigger value="simplified">Simplified Text</TabsTrigger>
          </TabsList>
          
          <TabsContent value="original" className="space-y-4">
            <Textarea
              value={originalText}
              onChange={(e) => setOriginalText(e.target.value)}
              placeholder="Enter complex text that you want to simplify..."
              className="min-h-[200px]"
            />
            
            <div className="space-y-2">
              <p className="text-sm font-medium">Simplification Level:</p>
              <div className="flex space-x-2">
                {["high", "medium", "low"].map((level) => (
                  <Button
                    key={level}
                    variant={complexity === level ? "default" : "outline"}
                    onClick={() => setComplexity(level)}
                    className="flex-1 capitalize"
                  >
                    {level === "high" ? "Mild" : level === "medium" ? "Moderate" : "Strong"}
                  </Button>
                ))}
              </div>
            </div>
            
            <Button 
              onClick={simplifyContent} 
              disabled={isSimplifying || !originalText}
              className="w-full"
            >
              {isSimplifying ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Simplifying...
                </>
              ) : (
                <>
                  <Wand2 className="mr-2 h-4 w-4" />
                  Simplify Text
                </>
              )}
            </Button>
          </TabsContent>
          
          <TabsContent value="simplified">
            <Textarea
              value={simplifiedText}
              readOnly
              placeholder="Simplified text will appear here..."
              className="min-h-[200px]"
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default ContentSimplifier;
