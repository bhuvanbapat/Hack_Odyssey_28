
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import LearnableCard from "@/components/LearnableCard";
import { BookOpen, FileText, ArrowRight, Ear, Eye, Brain, Edit, Check, Lightbulb } from "lucide-react";
import { useNavigate } from "react-router-dom";
import AIAssistant from "@/components/AIAssistant";

const Home = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Eye className="h-5 w-5 text-purple" />,
      title: "Visual Accessibility",
      description: "Text-to-speech, high contrast mode, and customizable fonts for visually impaired users."
    },
    {
      icon: <Ear className="h-5 w-5 text-purple" />,
      title: "Hearing Accessibility",
      description: "Speech-to-text transcription and visual alerts for hearing-impaired users."
    },
    {
      icon: <Brain className="h-5 w-5 text-purple" />,
      title: "Cognitive Support",
      description: "Content simplification and structured learning paths for cognitive disabilities."
    },
    {
      icon: <Edit className="h-5 w-5 text-purple" />,
      title: "Personalized Learning",
      description: "AI-tailored content and pace adjustments based on individual learning styles."
    },
    {
      icon: <Check className="h-5 w-5 text-purple" />,
      title: "Progress Tracking",
      description: "Monitor learning achievements with accessible visualizations and reports."
    },
    {
      icon: <Lightbulb className="h-5 w-5 text-purple" />,
      title: "Resource Recommendations",
      description: "AI-powered suggestions for educational resources based on individual needs."
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-12 md:py-20 bg-gradient-to-b from-purple-light/30 to-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center text-center space-y-4 md:space-y-6">
              <h1 className="text-3xl md:text-5xl font-bold tracking-tighter">
                Making Education <span className="text-purple">Accessible</span> For Everyone
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-[700px]">
                LearnAble is an AI-powered learning assistant designed to make education 
                inclusive and accessible for students with visual, hearing, and cognitive disabilities.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-4">
                <Button size="lg" onClick={() => navigate("/dashboard")}>
                  Get Started <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold">Accessible Learning Features</h2>
              <p className="text-muted-foreground mt-2 max-w-[600px] mx-auto">
                Our platform offers a variety of features designed to support different accessibility needs.
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <LearnableCard
                  key={index}
                  icon={feature.icon}
                  title={feature.title}
                  description={feature.description}
                  onClick={() => navigate("/dashboard")}
                />
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-16 bg-purple/5">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
              <div className="max-w-[600px]">
                <h2 className="text-2xl md:text-3xl font-bold">Ready to experience accessible learning?</h2>
                <p className="text-muted-foreground mt-2">
                  Create your personalized learning environment tailored to your specific needs.
                </p>
              </div>
              <Button size="lg" onClick={() => navigate("/dashboard")}>
                Go to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      {/* Footer */}
      <footer className="border-t py-6 md:py-8">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-purple" />
              <span className="font-medium">LearnAble</span>
            </div>
            
            <p className="text-sm text-muted-foreground">
              © 2025 LearnAble. All rights reserved.
            </p>
            
            <div className="flex space-x-4">
              <Link to="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Terms of Service
              </Link>
              <Link to="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </footer>
      
      {/* AI Assistant */}
      <AIAssistant 
        accessibilitySettings={{
          visualSupport: true,
          hearingSupport: true,
          cognitiveSupport: true
        }}
        initialMessage="Hello! I'm your personalized learning assistant. I can help with your educational journey based on your specific accessibility needs. Ask me anything about your studies!"
      />
    </div>
  );
};

export default Home;
