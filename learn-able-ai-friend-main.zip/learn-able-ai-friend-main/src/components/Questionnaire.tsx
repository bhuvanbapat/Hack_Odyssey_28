
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface QuestionnaireData {
  learningStyle: string;
  accessibilityNeeds: string[];
  challengesInLearning: string;
  preferredMediaTypes: string[];
  motivationLevel: number;
  additionalComments: string;
}

const Questionnaire: React.FC = () => {
  const [formData, setFormData] = useState<QuestionnaireData>({
    learningStyle: '',
    accessibilityNeeds: [],
    challengesInLearning: '',
    preferredMediaTypes: [],
    motivationLevel: 5,
    additionalComments: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Questionnaire Submitted:', formData);
    // In a real app, you'd send this data to a backend or state management system
  };

  const updateFormData = (key: keyof QuestionnaireData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <Card className="max-w-2xl mx-auto mt-8">
      <CardHeader>
        <CardTitle>Personalized Learning Assistant Questionnaire</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Learning Style Question */}
          <div>
            <Label>What is your preferred learning style?</Label>
            <select 
              value={formData.learningStyle}
              onChange={(e) => updateFormData('learningStyle', e.target.value)}
              className="w-full p-2 border rounded mt-2"
            >
              <option value="">Select Learning Style</option>
              <option value="visual">Visual Learner</option>
              <option value="auditory">Auditory Learner</option>
              <option value="kinesthetic">Kinesthetic Learner</option>
              <option value="reading-writing">Reading/Writing Learner</option>
            </select>
          </div>

          {/* Accessibility Needs */}
          <div>
            <Label>Select your accessibility needs:</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {[
                'Screen Reader Support', 
                'Color Contrast', 
                'Text-to-Speech', 
                'Speech-to-Text', 
                'Keyboard Navigation', 
                'Large Text Mode'
              ].map((need) => (
                <div key={need} className="flex items-center space-x-2">
                  <Checkbox 
                    checked={formData.accessibilityNeeds.includes(need)}
                    onCheckedChange={(checked) => {
                      const currentNeeds = formData.accessibilityNeeds;
                      const newNeeds = checked 
                        ? [...currentNeeds, need]
                        : currentNeeds.filter(n => n !== need);
                      updateFormData('accessibilityNeeds', newNeeds);
                    }}
                  />
                  <Label>{need}</Label>
                </div>
              ))}
            </div>
          </div>

          {/* Learning Challenges */}
          <div>
            <Label>Describe your main challenges in learning:</Label>
            <Textarea 
              value={formData.challengesInLearning}
              onChange={(e) => updateFormData('challengesInLearning', e.target.value)}
              placeholder="Share your learning challenges"
              className="mt-2"
            />
          </div>

          {/* Preferred Media Types */}
          <div>
            <Label>Preferred Learning Media:</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {[
                'Video Tutorials', 
                'Interactive Exercises', 
                'Audio Lessons', 
                'Infographics', 
                'Animated Explanations', 
                'Text Summaries'
              ].map((media) => (
                <div key={media} className="flex items-center space-x-2">
                  <Checkbox 
                    checked={formData.preferredMediaTypes.includes(media)}
                    onCheckedChange={(checked) => {
                      const currentMedia = formData.preferredMediaTypes;
                      const newMedia = checked 
                        ? [...currentMedia, media]
                        : currentMedia.filter(m => m !== media);
                      updateFormData('preferredMediaTypes', newMedia);
                    }}
                  />
                  <Label>{media}</Label>
                </div>
              ))}
            </div>
          </div>

          {/* Motivation Level */}
          <div>
            <Label>Rate your current motivation level for learning:</Label>
            <Input 
              type="range" 
              min="1" 
              max="10" 
              value={formData.motivationLevel}
              onChange={(e) => updateFormData('motivationLevel', Number(e.target.value))}
              className="mt-2"
            />
            <div className="text-center mt-2">
              Current Level: {formData.motivationLevel}/10
            </div>
          </div>

          {/* Additional Comments */}
          <div>
            <Label>Any additional comments or specific needs?</Label>
            <Textarea 
              value={formData.additionalComments}
              onChange={(e) => updateFormData('additionalComments', e.target.value)}
              placeholder="Share any additional information"
              className="mt-2"
            />
          </div>

          <Button type="submit" className="w-full">
            Submit Questionnaire
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default Questionnaire;
