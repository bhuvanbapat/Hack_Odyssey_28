
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Play, Pause, Volume2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

const TextToSpeech = () => {
  const [text, setText] = useState("");
  const [rate, setRate] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [volume, setVolume] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleSpeak = () => {
    if (!text) {
      toast.error("Please enter some text to speak");
      return;
    }

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate;
    utterance.pitch = pitch;
    utterance.volume = volume;

    utterance.onend = () => {
      setIsPlaying(false);
    };

    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
    toast.success("Text is being spoken");
  };

  return (
    <Card className="feature-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Volume2 className="mr-2 h-5 w-5 text-purple" />
          Text to Speech
        </CardTitle>
        <CardDescription>
          Convert written text to spoken words for easier comprehension
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="text-input">Enter Text:</Label>
          <Textarea
            id="text-input"
            placeholder="Type or paste text here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="min-h-[120px]"
          />
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="rate">Speech Rate</Label>
              <span>{rate.toFixed(1)}x</span>
            </div>
            <Slider
              id="rate"
              min={0.5}
              max={2}
              step={0.1}
              value={[rate]}
              onValueChange={(value) => setRate(value[0])}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="pitch">Pitch</Label>
              <span>{pitch.toFixed(1)}</span>
            </div>
            <Slider
              id="pitch"
              min={0.5}
              max={2}
              step={0.1}
              value={[pitch]}
              onValueChange={(value) => setPitch(value[0])}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="volume">Volume</Label>
              <span>{(volume * 100).toFixed(0)}%</span>
            </div>
            <Slider
              id="volume"
              min={0}
              max={1}
              step={0.1}
              value={[volume]}
              onValueChange={(value) => setVolume(value[0])}
            />
          </div>
        </div>

        <Button 
          onClick={handleSpeak} 
          className="w-full"
          variant={isPlaying ? "outline" : "default"}
        >
          {isPlaying ? (
            <>
              <Pause className="mr-2 h-4 w-4" /> Stop Speaking
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" /> Speak Text
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default TextToSpeech;
