
import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Bot, Send, User, X, Minimize, Maximize, Volume, Mic, MicOff } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  userName?: string;
  initialMessage?: string;
  accessibilitySettings?: {
    visualSupport?: boolean;
    hearingSupport?: boolean;
    cognitiveSupport?: boolean;
  };
}

const AIAssistant: React.FC<AIAssistantProps> = ({
  userName = "User",
  initialMessage = "Hello! I'm your personalized learning assistant. How can I help you today?",
  accessibilitySettings = {
    visualSupport: false,
    hearingSupport: false,
    cognitiveSupport: false,
  }
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [userInput, setUserInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize speech recognition
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = false;
      
      recognitionInstance.onresult = (event: any) => {
        const transcript = event.results[event.results.length - 1][0].transcript;
        setUserInput(transcript);
        
        // Auto-send the recognized speech
        if (transcript.trim()) {
          const userMessage: Message = {
            role: "user",
            content: transcript,
            timestamp: new Date()
          };
      
          setMessages((prev) => [...prev, userMessage]);
          setIsLoading(true);
      
          // Simulate response
          setTimeout(() => {
            generateResponse(transcript);
            setIsLoading(false);
          }, 1000);
        }
      };
      
      recognitionInstance.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        if (isListening) {
          setIsListening(false);
          toast.error("Speech recognition error. Please try again.");
        }
      };
      
      recognitionInstance.onend = () => {
        if (isListening) {
          recognitionInstance.start();
        }
      };
      
      setRecognition(recognitionInstance);
    }
    
    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [isListening]);

  // Create initial message from assistant
  useEffect(() => {
    setMessages([
      {
        role: "assistant",
        content: initialMessage,
        timestamp: new Date()
      }
    ]);
  }, [initialMessage]);

  // Auto scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!userInput.trim()) return;

    const userMessage: Message = {
      role: "user",
      content: userInput,
      timestamp: new Date()
    };

    setMessages((prev) => [...prev, userMessage]);
    setUserInput("");
    setIsLoading(true);

    // Simulate response (in a real app, this would call an API)
    setTimeout(() => {
      generateResponse(userInput);
      setIsLoading(false);
    }, 1000);
  };

  const generateResponse = (input: string) => {
    // In a real app, this would call an AI API based on the user's accessibility settings
    let responseContent = "";
    
    if (input.toLowerCase().includes("help") || input.toLowerCase().includes("support")) {
      responseContent = "I'm here to help! What specific learning topic would you like assistance with?";
    } else if (input.toLowerCase().includes("math") || input.toLowerCase().includes("mathematics")) {
      responseContent = "I can help explain math concepts in ways that work for your learning style. What specific math topic are you studying?";
    } else if (input.toLowerCase().includes("read") || input.toLowerCase().includes("reading")) {
      responseContent = "Reading can be challenging. Would you like me to help break down text into simpler parts or explain complex terminology?";
    } else if (input.toLowerCase().includes("write") || input.toLowerCase().includes("writing")) {
      responseContent = "I can help with writing by providing structures, templates, or helping organize your thoughts. What are you trying to write?";
    } else if (input.toLowerCase().includes("thank")) {
      responseContent = "You're welcome! I'm always here to support your learning journey.";
    } else {
      responseContent = `I understand you're asking about "${input}". Let me help you explore this topic based on your learning preferences.`;
    }

    // Adapt response based on accessibility settings
    if (accessibilitySettings.cognitiveSupport) {
      responseContent = responseContent
        .split(". ")
        .map(sentence => `• ${sentence}`)
        .join("\n");
    }

    const assistantMessage: Message = {
      role: "assistant",
      content: responseContent,
      timestamp: new Date()
    };

    setMessages((prev) => [...prev, assistantMessage]);
    
    // Automatically speak the response if hearing support is enabled
    if (accessibilitySettings.hearingSupport) {
      speakText(responseContent);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const toggleOpen = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setIsMinimized(false);
    }
  };

  // Speak text using speech synthesis
  const speakText = (text: string) => {
    if (window.speechSynthesis) {
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.cancel(); // Cancel any ongoing speech
      window.speechSynthesis.speak(utterance);
    }
  };

  // Handle text-to-speech for the last assistant message
  const speakLastMessage = () => {
    const lastAssistantMessage = [...messages]
      .reverse()
      .find(msg => msg.role === "assistant");
      
    if (lastAssistantMessage && window.speechSynthesis) {
      speakText(lastAssistantMessage.content);
      toast.success("Reading message aloud");
    }
  };

  // Toggle voice input
  const toggleVoiceInput = () => {
    if (!recognition) {
      toast.error("Speech recognition is not supported in this browser");
      return;
    }
    
    if (isListening) {
      recognition.stop();
      setIsListening(false);
      toast.success("Voice input disabled");
    } else {
      recognition.start();
      setIsListening(true);
      setUserInput("");
      toast.success("Voice input enabled. Speak now...");
    }
  };

  return (
    <>
      {!isOpen && (
        <Button
          onClick={toggleOpen}
          className="fixed bottom-6 right-6 rounded-full h-14 w-14 p-0 flex items-center justify-center shadow-md bg-purple hover:bg-purple/90"
        >
          <Bot className="h-6 w-6 text-white" />
        </Button>
      )}

      {isOpen && (
        <Card className={`fixed bottom-6 right-6 w-[350px] shadow-xl transition-all duration-300 ease-in-out ${
          isMinimized ? "h-14" : "h-[500px]"
        }`}>
          <CardHeader className="p-3 flex flex-row items-center justify-between space-y-0 border-b">
            <div className="flex items-center">
              <Avatar className="h-8 w-8 mr-2 bg-purple">
                <Bot className="h-4 w-4 text-white" />
              </Avatar>
              <div>
                <CardTitle className="text-sm">AI Learning Assistant</CardTitle>
                {!isMinimized && (
                  <CardDescription className="text-xs">
                    Personalized for your learning needs
                  </CardDescription>
                )}
              </div>
            </div>
            <div className="flex space-x-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={toggleMinimize}
              >
                {isMinimized ? <Maximize className="h-4 w-4" /> : <Minimize className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={toggleOpen}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>

          {!isMinimized && (
            <>
              <CardContent className="p-0 flex-grow overflow-hidden">
                <ScrollArea className="h-[380px] p-4">
                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={`mb-4 flex ${
                        message.role === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`flex max-w-[80%] rounded-lg p-3 ${
                          message.role === "user"
                            ? "bg-purple text-white"
                            : "bg-muted"
                        }`}
                      >
                        <div className="mr-2 mt-1">
                          {message.role === "user" ? (
                            <User className="h-4 w-4" />
                          ) : (
                            <Bot className="h-4 w-4" />
                          )}
                        </div>
                        <div>
                          <div className="text-sm whitespace-pre-line">{message.content}</div>
                          <div className="text-xs mt-1 opacity-70">
                            {message.timestamp.toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit"
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start mb-4">
                      <div className="bg-muted rounded-lg p-3 max-w-[80%]">
                        <div className="flex items-center space-x-2">
                          <div className="animate-pulse h-2 w-2 bg-current rounded-full"></div>
                          <div className="animate-pulse h-2 w-2 bg-current rounded-full animation-delay-200"></div>
                          <div className="animate-pulse h-2 w-2 bg-current rounded-full animation-delay-400"></div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </ScrollArea>
              </CardContent>

              <CardFooter className="p-3 border-t">
                <div className="flex w-full items-center space-x-2">
                  <Input
                    placeholder={isListening ? "Listening..." : "Type your message..."}
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    disabled={isListening}
                  />
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={toggleVoiceInput}
                    className={isListening ? "bg-red-100" : ""}
                    title={isListening ? "Stop listening" : "Start voice input"}
                  >
                    {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  </Button>
                  {accessibilitySettings.hearingSupport && (
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={speakLastMessage}
                      title="Read last message aloud"
                    >
                      <Volume className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    size="icon"
                    onClick={handleSend}
                    disabled={!userInput.trim() || isLoading || isListening}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </>
          )}
        </Card>
      )}
    </>
  );
};

export default AIAssistant;
