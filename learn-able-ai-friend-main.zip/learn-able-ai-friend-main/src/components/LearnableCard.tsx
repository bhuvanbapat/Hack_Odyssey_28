
import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface LearnableCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  ctaText?: string;
  onClick?: () => void;
}

const LearnableCard: React.FC<LearnableCardProps> = ({
  icon,
  title,
  description,
  ctaText = "Learn More",
  onClick,
}) => {
  return (
    <Card className="h-full transition-all duration-300 hover:shadow-md">
      <CardHeader>
        <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-purple-light/30">
          {icon}
        </div>
        <CardTitle className="text-xl">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {/* Card content goes here */}
      </CardContent>
      {onClick && (
        <CardFooter>
          <Button variant="outline" className="w-full" onClick={onClick}>
            {ctaText} <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default LearnableCard;
