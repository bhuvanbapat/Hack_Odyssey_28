import React, { useState } from "react";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Eye, Ear, Brain, User, Settings, Bell } from "lucide-react";
import { toast } from "sonner";
import AIAssistant from "@/components/AIAssistant";

const Profile = () => {
  const [visualSettings, setVisualSettings] = useState({
    highContrast: false,
    largeText: false,
    reducedMotion: true,
    textToSpeech: true,
    preferredVoice: "default",
    readingSpeed: 1
  });
  
  const [hearingSettings, setHearingSettings] = useState({
    autoTranscribe: true,
    showVisualAlerts: true,
    captionsEnabled: true,
    soundEffects: false
  });
  
  const [cognitiveSettings, setCognitiveSettings] = useState({
    contentSimplification: true,
    simplificationLevel: "medium",
    structuredFormat: true,
    extendedTime: true
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    resourceSuggestions: true,
    progressUpdates: true,
    learningReminders: false,
    accessibilityTips: true
  });
  
  const handleSaveSettings = () => {
    toast.success("Settings saved successfully");
  };
  
  const updateVisualSetting = (key: string, value: any) => {
    setVisualSettings(prev => ({ ...prev, [key]: value }));
  };
  
  const updateHearingSetting = (key: string, value: any) => {
    setHearingSettings(prev => ({ ...prev, [key]: value }));
  };
  
  const updateCognitiveSetting = (key: string, value: any) => {
    setCognitiveSettings(prev => ({ ...prev, [key]: value }));
  };
  
  const updateNotificationSetting = (key: string, value: any) => {
    setNotificationSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container px-4 py-6 md:px-6 md:py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">Accessibility Profile</h1>
              <p className="text-muted-foreground mt-1">
                Customize your learning experience to match your specific needs
              </p>
            </div>
            <Button onClick={handleSaveSettings}>Save Settings</Button>
          </div>
          
          <Tabs defaultValue="visual" className="space-y-6">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full">
              <TabsTrigger value="visual" className="flex items-center">
                <Eye className="h-4 w-4 mr-2" /> Visual
              </TabsTrigger>
              <TabsTrigger value="hearing" className="flex items-center">
                <Ear className="h-4 w-4 mr-2" /> Hearing
              </TabsTrigger>
              <TabsTrigger value="cognitive" className="flex items-center">
                <Brain className="h-4 w-4 mr-2" /> Cognitive
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center">
                <Bell className="h-4 w-4 mr-2" /> Notifications
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="visual">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Eye className="mr-2 h-5 w-5 text-purple" />
                    Visual Accessibility Settings
                  </CardTitle>
                  <CardDescription>
                    Customize the visual presentation of content to suit your needs
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="high-contrast">High Contrast Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        Improves text visibility with high contrast colors
                      </p>
                    </div>
                    <Switch 
                      id="high-contrast" 
                      checked={visualSettings.highContrast}
                      onCheckedChange={(value) => updateVisualSetting("highContrast", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="large-text">Large Text Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        Increases text size throughout the application
                      </p>
                    </div>
                    <Switch 
                      id="large-text" 
                      checked={visualSettings.largeText}
                      onCheckedChange={(value) => updateVisualSetting("largeText", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="reduced-motion">Reduced Motion</Label>
                      <p className="text-sm text-muted-foreground">
                        Minimizes animations and transitions
                      </p>
                    </div>
                    <Switch 
                      id="reduced-motion" 
                      checked={visualSettings.reducedMotion}
                      onCheckedChange={(value) => updateVisualSetting("reducedMotion", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="text-to-speech">Text-to-Speech</Label>
                      <p className="text-sm text-muted-foreground">
                        Enables automatic reading of text content
                      </p>
                    </div>
                    <Switch 
                      id="text-to-speech" 
                      checked={visualSettings.textToSpeech}
                      onCheckedChange={(value) => updateVisualSetting("textToSpeech", value)}
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <Label htmlFor="voice-select">Preferred Voice</Label>
                    <Select 
                      value={visualSettings.preferredVoice}
                      onValueChange={(value) => updateVisualSetting("preferredVoice", value)}
                    >
                      <SelectTrigger id="voice-select">
                        <SelectValue placeholder="Select a voice" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Default</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="male">Male</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <Label htmlFor="reading-speed">Reading Speed</Label>
                      <span>{visualSettings.readingSpeed.toFixed(1)}x</span>
                    </div>
                    <Slider
                      id="reading-speed"
                      min={0.5}
                      max={2}
                      step={0.1}
                      value={[visualSettings.readingSpeed]}
                      onValueChange={(value) => updateVisualSetting("readingSpeed", value[0])}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="hearing">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Ear className="mr-2 h-5 w-5 text-purple" />
                    Hearing Accessibility Settings
                  </CardTitle>
                  <CardDescription>
                    Customize audio features and alternatives for hearing support
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="auto-transcribe">Automatic Transcription</Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically transcribe audio content
                      </p>
                    </div>
                    <Switch 
                      id="auto-transcribe" 
                      checked={hearingSettings.autoTranscribe}
                      onCheckedChange={(value) => updateHearingSetting("autoTranscribe", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="visual-alerts">Visual Alerts</Label>
                      <p className="text-sm text-muted-foreground">
                        Display visual notifications for important audio events
                      </p>
                    </div>
                    <Switch 
                      id="visual-alerts" 
                      checked={hearingSettings.showVisualAlerts}
                      onCheckedChange={(value) => updateHearingSetting("showVisualAlerts", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="captions">Enable Captions</Label>
                      <p className="text-sm text-muted-foreground">
                        Show captions for all video content
                      </p>
                    </div>
                    <Switch 
                      id="captions" 
                      checked={hearingSettings.captionsEnabled}
                      onCheckedChange={(value) => updateHearingSetting("captionsEnabled", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="sound-effects">Sound Effects</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable non-verbal audio cues and effects
                      </p>
                    </div>
                    <Switch 
                      id="sound-effects" 
                      checked={hearingSettings.soundEffects}
                      onCheckedChange={(value) => updateHearingSetting("soundEffects", value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="cognitive">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="mr-2 h-5 w-5 text-purple" />
                    Cognitive Support Settings
                  </CardTitle>
                  <CardDescription>
                    Adjust content complexity and presentation to support cognitive needs
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="content-simplification">Content Simplification</Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically simplify complex content
                      </p>
                    </div>
                    <Switch 
                      id="content-simplification" 
                      checked={cognitiveSettings.contentSimplification}
                      onCheckedChange={(value) => updateCognitiveSetting("contentSimplification", value)}
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <Label htmlFor="simplification-level">Simplification Level</Label>
                    <Select 
                      value={cognitiveSettings.simplificationLevel}
                      onValueChange={(value) => updateCognitiveSetting("simplificationLevel", value)}
                    >
                      <SelectTrigger id="simplification-level">
                        <SelectValue placeholder="Select level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Mild Simplification</SelectItem>
                        <SelectItem value="medium">Moderate Simplification</SelectItem>
                        <SelectItem value="high">Strong Simplification</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="structured-format">Structured Format</Label>
                      <p className="text-sm text-muted-foreground">
                        Present content in clearly structured formats
                      </p>
                    </div>
                    <Switch 
                      id="structured-format" 
                      checked={cognitiveSettings.structuredFormat}
                      onCheckedChange={(value) => updateCognitiveSetting("structuredFormat", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="extended-time">Extended Time</Label>
                      <p className="text-sm text-muted-foreground">
                        Allow more time for completing interactive exercises
                      </p>
                    </div>
                    <Switch 
                      id="extended-time" 
                      checked={cognitiveSettings.extendedTime}
                      onCheckedChange={(value) => updateCognitiveSetting("extendedTime", value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bell className="mr-2 h-5 w-5 text-purple" />
                    Notification Settings
                  </CardTitle>
                  <CardDescription>
                    Customize which notifications you receive
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="resource-suggestions">Resource Suggestions</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive suggestions for new learning resources
                      </p>
                    </div>
                    <Switch 
                      id="resource-suggestions" 
                      checked={notificationSettings.resourceSuggestions}
                      onCheckedChange={(value) => updateNotificationSetting("resourceSuggestions", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="progress-updates">Progress Updates</Label>
                      <p className="text-sm text-muted-foreground">
                        Get updates about your learning progress
                      </p>
                    </div>
                    <Switch 
                      id="progress-updates" 
                      checked={notificationSettings.progressUpdates}
                      onCheckedChange={(value) => updateNotificationSetting("progressUpdates", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="learning-reminders">Learning Reminders</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive reminders to continue your learning
                      </p>
                    </div>
                    <Switch 
                      id="learning-reminders" 
                      checked={notificationSettings.learningReminders}
                      onCheckedChange={(value) => updateNotificationSetting("learningReminders", value)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="accessibility-tips">Accessibility Tips</Label>
                      <p className="text-sm text-muted-foreground">
                        Get suggestions to improve your accessibility experience
                      </p>
                    </div>
                    <Switch 
                      id="accessibility-tips" 
                      checked={notificationSettings.accessibilityTips}
                      onCheckedChange={(value) => updateNotificationSetting("accessibilityTips", value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <AIAssistant 
        accessibilitySettings={{
          visualSupport: true,
          hearingSupport: true,
          cognitiveSupport: true
        }}
        initialMessage="Need help configuring your accessibility profile? I can guide you through optimizing your settings based on your specific needs."
      />
    </div>
  );
};

export default Profile;
