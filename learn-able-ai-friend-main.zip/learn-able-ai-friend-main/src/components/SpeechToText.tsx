
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mic, Copy, Save } from "lucide-react";
import { toast } from "sonner";

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const SpeechToText = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    // Initialize speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      
      recognitionInstance.onresult = (event: any) => {
        let currentTranscript = "";
        for (let i = 0; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);
      };
      
      recognitionInstance.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        setIsListening(false);
        toast.error("Speech recognition error: " + event.error);
      };
      
      recognitionInstance.onend = () => {
        if (isListening) {
          recognitionInstance.start();
        }
      };
      
      setRecognition(recognitionInstance);
    } else {
      toast.error("Speech recognition is not supported in this browser");
    }
    
    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, []);

  const toggleListening = () => {
    if (!recognition) {
      toast.error("Speech recognition is not supported in this browser");
      return;
    }
    
    if (isListening) {
      recognition.stop();
      setIsListening(false);
      toast.success("Speech recognition stopped");
    } else {
      recognition.start();
      setIsListening(true);
      toast.success("Listening... Speak now");
    }
  };

  const copyToClipboard = () => {
    if (!transcript) {
      toast.error("No text to copy");
      return;
    }
    
    navigator.clipboard.writeText(transcript)
      .then(() => toast.success("Text copied to clipboard"))
      .catch(() => toast.error("Failed to copy text"));
  };

  const saveTranscript = () => {
    if (!transcript) {
      toast.error("No text to save");
      return;
    }
    
    const blob = new Blob([transcript], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "transcript.txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Transcript saved as text file");
  };

  return (
    <Card className="feature-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Mic className="mr-2 h-5 w-5 text-purple" />
          Speech to Text
        </CardTitle>
        <CardDescription>
          Convert spoken words to written text for accessibility
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          value={transcript}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder="Your transcribed text will appear here..."
          className="min-h-[150px]"
        />
        
        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            onClick={toggleListening} 
            className={`flex-1 ${isListening ? "bg-red-500 hover:bg-red-600" : ""}`}
          >
            <Mic className="mr-2 h-4 w-4" />
            {isListening ? "Stop Listening" : "Start Listening"}
          </Button>
          
          <Button variant="outline" onClick={copyToClipboard} className="flex-1">
            <Copy className="mr-2 h-4 w-4" />
            Copy Text
          </Button>
          
          <Button variant="outline" onClick={saveTranscript} className="flex-1">
            <Save className="mr-2 h-4 w-4" />
            Save as File
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default SpeechToText;
