
import React, { useState } from "react";
import Header from "@/components/Header";
import TextToSpeech from "@/components/TextToSpeech";
import SpeechToText from "@/components/SpeechToText";
import ContentSimplifier from "@/components/ContentSimplifier";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, FileText, Lightbulb, BarChart } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import AIAssistant from "@/components/AIAssistant";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("tools");
  
  const learningProgress = [
    { subject: "Mathematics", progress: 65 },
    { subject: "Science", progress: 45 },
    { subject: "Literature", progress: 80 },
    { subject: "History", progress: 30 },
  ];
  
  const recommendedResources = [
    {
      title: "Introduction to Algebra",
      type: "Interactive Tutorial",
      description: "A beginner-friendly guide to algebraic concepts with visual aids.",
      accessibilityFeatures: ["Visual Support", "Simplified Language"]
    },
    {
      title: "History Through Stories",
      type: "Audio Series",
      description: "Learn history through engaging narratives and storytelling.",
      accessibilityFeatures: ["Audio Format", "Transcripts Available"]
    },
    {
      title: "Science Concepts Explained Simply",
      type: "Article Collection",
      description: "Complex scientific ideas broken down into easy-to-understand explanations.",
      accessibilityFeatures: ["Simplified Language", "Visual Diagrams"]
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container px-4 py-6 md:px-6 md:py-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-6">Learning Dashboard</h1>
        
        <Tabs 
          defaultValue="tools" 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="space-y-6"
        >
          <TabsList className="grid grid-cols-3 w-full max-w-[600px]">
            <TabsTrigger value="tools">Accessibility Tools</TabsTrigger>
            <TabsTrigger value="progress">Learning Progress</TabsTrigger>
            <TabsTrigger value="resources">Recommended Resources</TabsTrigger>
          </TabsList>
          
          <TabsContent value="tools" className="space-y-6">
            <div className="grid grid-cols-1 gap-6">
              <TextToSpeech />
              <SpeechToText />
              <ContentSimplifier />
            </div>
          </TabsContent>
          
          <TabsContent value="progress">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart className="mr-2 h-5 w-5 text-purple" />
                  Learning Progress
                </CardTitle>
                <CardDescription>
                  Track your progress across different subjects
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {learningProgress.map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between">
                        <p className="font-medium">{item.subject}</p>
                        <p className="text-muted-foreground">{item.progress}%</p>
                      </div>
                      <Progress value={item.progress} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="resources">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Lightbulb className="mr-2 h-5 w-5 text-purple" />
                  Personalized Resource Recommendations
                </CardTitle>
                <CardDescription>
                  Resources tailored to your learning style and accessibility needs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {recommendedResources.map((resource, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:bg-secondary/20 transition-colors">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">{resource.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1">{resource.type}</p>
                        </div>
                        <button className="text-sm text-purple hover:underline">
                          View Resource
                        </button>
                      </div>
                      <p className="text-sm mt-2">{resource.description}</p>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {resource.accessibilityFeatures.map((feature, i) => (
                          <span 
                            key={i} 
                            className="text-xs px-2 py-1 bg-secondary rounded-full"
                          >
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      {/* AI Assistant */}
      <AIAssistant 
        accessibilitySettings={{
          visualSupport: true,
          hearingSupport: true,
          cognitiveSupport: true
        }}
        initialMessage="I'm here to help with your dashboard! Looking for learning resources or assistance with specific subjects? Just ask me."
      />
    </div>
  );
};

export default Dashboard;
