
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Eye,
  EyeOff,
  Ear,
  BookOpen,
  User,
  Menu,
  X,
  Home,
  Settings,
  Moon,
  Sun,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Header = () => {
  const isMobile = useIsMobile();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const toggleHighContrast = () => {
    document.body.classList.toggle("high-contrast");
    setHighContrast(!highContrast);
  };
  
  const toggleLargeText = () => {
    document.body.classList.toggle("large-text");
    setLargeText(!largeText);
  };
  
  const toggleDarkMode = () => {
    document.body.classList.toggle("dark");
    setDarkMode(!darkMode);
  };

  return (
    <header className="border-b py-4 px-4 md:px-6 bg-background sticky top-0 z-10">
      <div className="container flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <BookOpen className="h-6 w-6 text-purple" />
          <span className="font-bold text-xl">LearnAble</span>
        </Link>
        
        {isMobile ? (
          <>
            <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Menu">
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            
            {isMenuOpen && (
              <div className="fixed inset-0 top-16 bg-background z-50 animate-fade-in p-4">
                <nav className="flex flex-col space-y-2">
                  <Link to="/" className="accessibility-nav-item" onClick={toggleMenu}>
                    <Home className="inline-block mr-2 h-5 w-5" /> Home
                  </Link>
                  <Link to="/dashboard" className="accessibility-nav-item" onClick={toggleMenu}>
                    <BookOpen className="inline-block mr-2 h-5 w-5" /> Dashboard
                  </Link>
                  <Link to="/profile" className="accessibility-nav-item" onClick={toggleMenu}>
                    <User className="inline-block mr-2 h-5 w-5" /> Profile
                  </Link>
                  <hr className="my-2" />
                  <button 
                    className="accessibility-nav-item flex items-center" 
                    onClick={toggleHighContrast}
                  >
                    {highContrast ? <EyeOff className="mr-2 h-5 w-5" /> : <Eye className="mr-2 h-5 w-5" />}
                    {highContrast ? "Standard Contrast" : "High Contrast"}
                  </button>
                  <button 
                    className="accessibility-nav-item flex items-center" 
                    onClick={toggleLargeText}
                  >
                    {largeText ? <ZoomOut className="mr-2 h-5 w-5" /> : <ZoomIn className="mr-2 h-5 w-5" />}
                    {largeText ? "Standard Text" : "Large Text"}
                  </button>
                  <button 
                    className="accessibility-nav-item flex items-center" 
                    onClick={toggleDarkMode}
                  >
                    {darkMode ? <Sun className="mr-2 h-5 w-5" /> : <Moon className="mr-2 h-5 w-5" />}
                    {darkMode ? "Light Mode" : "Dark Mode"}
                  </button>
                </nav>
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center space-x-4">
            <nav className="flex items-center space-x-4 mr-4">
              <Link to="/" className="accessibility-nav-item">Home</Link>
              <Link to="/dashboard" className="accessibility-nav-item">Dashboard</Link>
              <Link to="/profile" className="accessibility-nav-item">Profile</Link>
            </nav>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center">
                  <Settings className="h-4 w-4 mr-2" />
                  Accessibility
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={toggleHighContrast}>
                  {highContrast ? <EyeOff className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
                  {highContrast ? "Standard Contrast" : "High Contrast"}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={toggleLargeText}>
                  {largeText ? <ZoomOut className="mr-2 h-4 w-4" /> : <ZoomIn className="mr-2 h-4 w-4" />}
                  {largeText ? "Standard Text" : "Large Text"}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={toggleDarkMode}>
                  {darkMode ? <Sun className="mr-2 h-4 w-4" /> : <Moon className="mr-2 h-4 w-4" />}
                  {darkMode ? "Light Mode" : "Dark Mode"}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Link to="/profile">
              <Button variant="ghost" size="icon" aria-label="Profile">
                <User className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
